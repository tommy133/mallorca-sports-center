- Categoria principal: centres esportius
Aquests són els espais dissenyats per dur-se terme una activitat física de qualsevol tipus, oferint programes d'exercicis i ultilitzan equips i tècniques d'entrenament i preparació, amb personal qualificat per garantitzar la seguretat i la satisfacció de la pràctica deportiva.

- sport: tipus d'esport que es duu a terme al centre.
- organizations: llistat d'empreses que es dediquen a oferir un esport determinat als seus centres


